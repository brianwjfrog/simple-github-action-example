# Notes for build 
**Build Number**: 161267
**Build Trigger PR Number**:  

# Associated Pull Requests (0)

# Global list of CS (11)
### Associated commits  (only shown if CS) 
* ** ID55af8cecfbb8692a0e68d2f331aa3b0f2c531221** 
  -  **Message:** Merge branch &#x27;master&#x27; of https://dev.azure.com/AEMO-Application-Delivery/sample/_git/sample-dotnet-service
  -  **Commited by:** Chris Graham 

* ** ID49b9191fe881bcc1c5e2a35d8e52f803ee4b94fc** 
  -  **Message:** Fix sub-dependies
  -  **Commited by:** Chris Graham 

* ** IDda6ba072168f5224ed87864b7bea3111d4c3d085** 
  -  **Message:** Update .NET SDK to 6.0.317
  -  **Commited by:** Chris Graham 

* ** ID84c07eb8d19a8a78aca5f456681fb8c8a434e602** 
  -  **Message:** .net sdk 6.0.122
  -  **Commited by:** Chris Graham 

* ** IDcbd755f6042be7554a6e57391cadd39478da50ca** 
  -  **Message:** .net sdk 6.0.22
  -  **Commited by:** Chris Graham 

* ** IDa5e4b771ba24c672f879ad2bd025787bb5f32d6f** 
  -  **Message:** .net sdk version 6.0.15
  -  **Commited by:** Chris Graham 

* ** ID0ef0bd204a2e35a42ef94f8564ee1b7964979b47** 
  -  **Message:** try downgrading to 6.0.413
  -  **Commited by:** Chris Graham 

* ** ID5b74b188cbf31bb28e403b5e4bf136e5a658d48c** 
  -  **Message:** downgrade .net sdk version to 6.0.302
  -  **Commited by:** Chris Graham 

* ** IDc3fd0f13074237392d0c86b1eb4907412f4c0cf6** 
  -  **Message:** Upgrade to commoncode
  -  **Commited by:** Chris Graham 

* ** IDfdfab8687f16cb0c8d9bb32307a3b5ad189ccf85** 
  -  **Message:** Configure pipelines for new api pattern
  -  **Commited by:** Chris Graham 

* ** IDc3b52fbdd31cbf83d2aa1bd53b31bb13aacebe1b** 
  -  **Message:** Sample project updated
  -  **Commited by:** PAlexander 

## Global list of ConsumedArtifacts (2)
| Category | Type | Version Name | Version Id | Commits | Workitems |
|-|-|-|-|-|-|
|Repository | TfsGit |  | f7e03c0 |  |  |
|Repository | TfsGit |  | f7e03c0 |  |  |
